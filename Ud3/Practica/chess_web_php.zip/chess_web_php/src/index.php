<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>AJEDREZ</title>
    <link rel="stylesheet" type="text/css"  href="../style.css">
</head>



<body>

    <header>
        <h1><a href="index.php">CHESS</a></h1> <p>GAME</p>
        <div class="horizontal-menu">
            <ul>
                <li><a href="new_GameView.php" class="horizotal-menu-link">NEW GAME</a></li>
                <li><a href="gamesListView.php" class="horizotal-menu-link">GAMES LIST</a></li>
            </ul>
        </div>
    </header>
    
    <nav>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Harum laudantium minima reiciendis vitae debitis. Dolorem laborum repudiandae voluptatem nesciunt natus asperiores facere ducimus facilis beatae eos. Velit totam voluptate minus?</p>
    </nav>

    <footer><b>&#169 CHESS GAME</b></footer>

</body>

</html>